﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace zadanko
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void but1_Click(object sender, RoutedEventArgs e)
        {
            CC.Content = new UserControl1();
        }

        private void but2_Click(object sender, RoutedEventArgs e)
        {
            CC.Content = new UserControl2();
        }

        private void but3_Click(object sender, RoutedEventArgs e)
        {
            CC.Content = new UserControl3();
        }
    }
}